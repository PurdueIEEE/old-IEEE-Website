function [pi_est, dir, rel_err] = leibniz_pi(targ_err)
%LEIBNIZ_PI uses the Leibniz formula to estimate the value of pi.
%
% Call: [pi_est, dir, rel_err] = leibniz_pi(start_est, targ_err)
%
% Inputs:
% targ_err  = Desired magnitude of relative error at end of execution
%
% Outputs:
% pi_est    = Best estimate of pi
% dir       = String stating how estimate compares to accepted value
% rel_err   = Relative error of pi at end of executiion
% 
% 
% Author: Michael Hayashi
% Purdue IEEE Student Branch
% Email: mhayashi@purdue.edu
% Introduction to MATLAB Workshop
% Sublinear Estimation of Pi Function
% 16 November 2017
% Accessible: https://purdueieee.org/learning/matlab
% Version: MATLAB(R) 2015b
% Test Case Runtime: 0.135 s (targ_err = 4.7e-7)

indk = 0;
pi_est = 4.0; % First term in summation
rel_err = (pi_est - pi) / pi;
while abs(rel_err) > targ_err
    indk = indk + 1;
    pi_est = pi_est + (-1) ^ indk * 4 / (2 * indk + 1);
    rel_err = (pi_est - pi) / pi;
end
switch sign(rel_err)
    case +1
        dir = 'greater than';
    case -1
        dir = 'less than';
    otherwise
        dir = '(within the precision of MATLAB) equal to';
end

end