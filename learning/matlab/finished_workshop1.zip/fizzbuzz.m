%% Header
% Author: Michael Hayashi
% Purdue IEEE Student Branch
% Email: mhayashi@purdue.edu
% Introduction to MATLAB Workshop
% Game of Fizz Buzz Bang
% 16 November 2017
% Accessible: https://purdueieee.org/learning/matlab
% Version: MATLAB(R) 2015b
% Runtime: 0.094 s
close('all')
clearvars
clc

%% Game

% Initialize Game Parameters
game_start = 1;
game_end = 200;

% Test Each Number in Bounds Before Displaying Result
for indi = game_start:game_end
    % Test Divisbility
    fizz_test = (mod(indi, 3) == 0);
    buzz_test = (mod(indi, 5) == 0);
    bang_test = (mod(indi, 7) == 0);

    % Know Many Tests Were Passed
    pass_count = fizz_test + buzz_test + bang_test;

    % Only Use the Word if Specific Divisibility Test Passed
    if fizz_test
        word1 = 'Fizz';
    else
        word1 = '';
    end
    if buzz_test
        word2 = 'Buzz';
    else
        word2 = '';
    end
    if bang_test
        word3 = 'Bang';
    else
        word3 = '';
    end

    % Assemble Output String with Concatention and Print
    if pass_count == 1
        str_out = ['(', word1, word2, word3, ')'];
    elseif pass_count == 2
        str_out = ['[', word1, word2, word3, ']'];
    elseif pass_count == 3
        str_out = ['{', word1, word2, word3, '}'];
    else
        str_out = num2str(indi);
    end
    fprintf(1, '%s\n', str_out);
end