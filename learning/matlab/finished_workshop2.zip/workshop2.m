%% Header
% Script to follow along with the More on Basic MATLAB Workshop.

% Written by: Michael Hayashi
% Purdue IEEE Student Branch
% 26 December 2017
% Version: MATLAB(R) R2015b
close('all')
clearvars
clc

%% Exploration

% mat1 = [28, 147, -65, 92; 46, 88, -72, 41; ...
%     64, 30, -79, -9; 82, -21, -86, -61];
% 
% figure(1)
% imagesc(mat1)
% colorbar
% % heatmap(mat1)
% 
% figure(2)
% stem3(mat1, 'filled')
% 
% figure(3)
% plotmatrix(randn(100, 2))

% mat1 = [(1:6).', (7:12).', (13:18).', (19:24).', (25:30).', (31:36).'];
% vec1 = randperm(size(mat1, 2));
% vec2 = (5:5:20).';
% mat2 = diag(vec2);
% mat3 = blkdiag(mat2, mat1);
% mat4 = reshape([mat1(:); (37:49).'], 7, 7);
% 
% disp('Row-column and linear indexing for matrices:')
% disp(mat1(3,4))
% disp(mat1(12))
% disp('Diagonal matrix from vector:')
% disp(mat2)
% disp('Diagonal extracted from matrix:')
% disp(diag(mat1))
% disp('Randomize column order')
% disp(mat1(:,vec1))
% disp('Concatenating matrices into block diagonal form:')
% disp(mat3)
% disp('Repeating a vector:')
% disp(repmat(vec1, 7, 1))
% disp('Repeating a matrix:')
% disp(repmat(mat2, 2, 2))
% disp('Reshaping arrays:')
% disp(mat4)

% mat1 = [13, -10, 4, -18; -10, 25, -5, 3; ...
%     4, -5, 9, -12; -18, 3, -12, 17];
% % mat2 = [13, -10, 4, -8; -10, 25, -5, 3; ...
% %     4, -5, 9, -2; -8, 3, -2, 17];
% [mat1_L, mat1_U, mat1_P] = lu(mat1);
% [mat1_Q, mat1_R] = qr(mat1);
% [mat1_V, mat1_D] = eig(mat1);
% 
% fprintf(1, 'Trace: %1.2g\n', trace(mat1));
% fprintf(1, 'Rank estimate: %1.2g\n', rank(mat1));
% fprintf(1, 'Condition number: %1.2g\n', cond(mat1));
% fprintf(1, 'Determinant estimate: %1.2g\n', det(mat1));
% fprintf(1, '2-norm: %1.2g\n', norm(mat1, 2));
% fprintf(1, 'Frobenius norm: %1.2g\n', norm(mat1, 'fro'));
% disp('Reduced row echelon form:')
% disp(rref(mat1))
% disp('Matrix inverse:')
% disp(inv(mat1))
% disp('Orthonormal basis of nullspace:')
% disp(null(mat1))
% disp('Orthonormal basis of range (Gram-Schmidt result on columns):')
% disp(orth(mat1))
% disp('LU(P) decomposition:')
% disp(' strictly lower triangular L:')
% disp(mat1_L)
% disp(' and upper triangular U:')
% disp(mat1_U)
% disp(' and permutation P:')
% disp(mat1_P)
% disp('QR decomposition:')
% disp(' unitary Q:')
% disp(mat1_Q)
% disp(' upper triangular R:')
% disp(mat1_R)
% disp('Eigendecomposition/Spectral decomposition:')
% disp(' matrix of normalized right eigenvectors V:')
% disp(mat1_V)
% disp(' diagonal matrix of corresponding eigenvalues D:')
% disp(mat1_D)

% timestamp_now = datetime;
% timestamp_update = timestamp_now.Minute + 1;
% month_end = dateshift(timestamp_now, 'end', 'month');
% [~, weekday_month_end] = weekday(month_end);
% 
% found_Purdue = datetime(1869, 05, 06);
% found_Purdue.Format = 'MMM dd, yyyy';
% time_since_found = days(timestamp_now - found_Purdue);
% sesquicentennial = calyears(150);
% sesqui_Purdue = found_Purdue + sesquicentennial;
% 
% found_IEEE = datetime(1903, 01, 26, 15, 56, 28);
% recharter_IEEE = datetime(1963, 01, 03, 08, 00, 01);
% [years_between, months_between, days_between] = ...
%     split(between(found_IEEE, recharter_IEEE), ...
%     {'years', 'months', 'days'});
% 
% disp(class(timestamp_now))
% disp('The current date and time:')
% disp(timestamp_now)
% disp(datevec(timestamp_now))
% disp(year(timestamp_now))
% disp(quarter(timestamp_now))
% disp(week(timestamp_now))
% disp('The next minute:')
% disp(timestamp_update)
% disp('The last day of the month:')
% disp(month_end)
% disp('When Purdue was founded (American format):')
% disp(found_Purdue)
% disp('When Purdue IEEE was founded:')
% disp(found_IEEE)
% 
% fprintf(1, '\nThe last day of the month is %s, %s.\n', ...
%  weekday_month_end, datestr(month_end, 'mmm dd, yyyy'));
% fprintf(1, ['It has been %1.0f days since the founding of ' ...
%  'Purdue University.\n'], time_since_found);
% fprintf(1, 'The Purdue sesquicentennial is on %s.\n', ...
%  datestr(sesqui_Purdue));
% fprintf(1, ['Purdue IEEE was rechartered on %s after ' ...
%     '%1.0f years,\n%1.0f months, and %1.0f days of ' ...
%     'existence.\n\n'], datestr(recharter_IEEE), years_between, ...
%     months_between, days_between);

% first_name = input('What is your first name?\n', 's');
% last_name = input('What is your last name?\n', 's');
% birth_year = input('In what year were you born?\n');
% phone_number = input('What is your phone number?\n', 's');
% 
% N_max = input('What is the most possible numbers to handle?\n');
% end_early_flag = false;
% scores = nan(N_max, 1);
% for indi = 1:N_max
%     if end_early_flag
%         break
%     end
%     while true
%         num_input = input(sprintf('Please enter score #%d: ', ...
%             indi), 's');
%         if strcmp(num_input, 'stop')
%             end_early_flag = true;
%             break
%         end
%         if isfinite(str2double(num_input))
%             scores(indi) = str2double(num_input);
%             break
%         end
%     end
% end
% 
% phone_digits = double(phone_number);
% phone_digits((phone_digits < 48) | (phone_digits > 57)) = '';
% phone_digits = str2double(char(phone_digits));
% switch isprime(phone_digits)
%     case 1
%         prime_str = 'is';
% 	case 0
%         prime_str = 'is not';
% end
% 
% fprintf(1, 'The average score is %1.2f.\n', nanmean(scores));
% fprintf(1, '%s, your phone number %s prime.\n', first_name, prime_str);

% names = {'Jane Doe'; 'Yash Nain'; 'Michael Hayashi'};
% str_array = char(names);
% [name1, name2, name3] = deal(names{:});
% document_info = {'Sponsor', 'Purdue IEEE Student Branch'; ...
%     'Date', date; 'Version', 'R2015b'; 'Attendees', 50; ...
%     'Authors', names; 'Mentors', cell(0, 0)};
% 
% disp('The authors:')
% disp(names)
% disp('Left-justified author character array:')
% disp(str_array)
% disp('The third author (value):')
% disp(name3)
% disp('The second and third authors (cells):')
% disp(names(2:3))
% disp('The second author (cell contents):')
% disp(names{2})
% disp('Document metadata:')
% disp(size(document_info))
% disp(document_info)
% 
% document_info{6,2} = {names{2}; names{end}; 'Albert Xu'; ...
% 'Nataliia Perova-Mello'; 'Ivan Ostroumov'};
% disp('Updated document metadata:')
% disp(document_info)
% 
% fprintf(1, ['\nThis document was written by %s, %s, and %s.\n' ...
%     'All materials brought to you by %s.\n' ...
%     'Please use MATLAB %s %s.\n' ...
%     'Direct questions to %s.\n\n'], ...
%     name1, strtrim(char(names(2))), names{3}, document_info{1,2}, ...
%     document_info{3,1}, document_info{3,2}, document_info{5,2}{3});

% officers_IEEE_2017 = readtable('IEEE_officers.csv');
% officers_cell = table2cell(officers_IEEE_2017);
% officers_struct = table2struct(officers_IEEE_2017);
% officers_IEEE_2017.Properties.Description = ['Table of Purdue IEEE ' ...
%     'Student Branch officers throughout 2017-2018 academic year'];
% officers_IEEE_2017.Properties.VariableDescriptions = ...
%     {'First and Last Name', 'Voting Position Held Spring Semester', ...
%     'Voting Position Held Fall Semester', ...
%     'Self-identified year in college', 'Field of Degree Sought'};
% officers_IEEE_2017.Properties.VariableUnits{'PositionForSpring2018'} ...
%     = 'Executive / Cornerstones / Technical Cmte / Event Cmte';
% officers_IEEE_2017.Properties.VariableUnits{'PositionForFall2017'} ...
%     = 'Executive / Cornerstones / Technical Cmte / Event Cmte';
% officers_IEEE_2017.Properties.VariableUnits{'YearOfStudy'} = ...
%     'Freshmen / Sophomore / Junior / Senior / Graduate';
% officers_IEEE_2017.Properties.DimensionNames{1} = 'Voting Member';
% 
% disp(officers_IEEE_2017)
% fprintf(1, ['Number of elements: %1d, Size of table: [%1d, %1d]\n' ...
%     'Height: %1d, Width: %1d\n'], numel(officers_IEEE_2017), ...
%     size(officers_IEEE_2017), height(officers_IEEE_2017), ...
%     width(officers_IEEE_2017));
% summary(officers_IEEE_2017)
% 
% officers_IEEE_2017.ActiveYears = [4; 2; 3; 2; 1; 1.5; 1; 2; 2.5; 4; ...
%     2; 2; 3; 4.5; 1.5; 2; 3; 2];
% officers_IEEE_2017.Properties.VariableDescriptions{6} = ...
%     'Number of Years in Purdue IEEE Student Branch';
% officers_IEEE_2017.Properties.VariableUnits{6} = 'Years';
% active_S2018 = sortrows(officers_IEEE_2017, [6, 1], ...
%     {'descend', 'ascend'});
% gone_Spring2018 = strcmp(active_S2018.PositionForSpring2018, '');
% active_S2018(gone_Spring2018,:) = [];
% active_S2018.Properties.Description = ['Table of Purdue IEEE ' ...
%     'Student Branch officers for Spring 2018 by active years'];
% 
% fprintf(1, '\n\n');
% summary(active_S2018)
% writetable(active_S2018, 'IEEE_officer_seniority.csv')