% var1 = 55.1;
% var2 = 2;
% var3 = 46372819;
% var4 = 'c';
% var5 = 'Hello World!';
% var6 = false;
% var7 = @help;
% 
% result1 = var1 + var2;
% result2 = var3 - var2;
% result3 = var1 * var2;
% result4 = var3 / var1;
% result5 = var1 \ var3;
% result6 = var1 ^ var2;
% result7 = (var1 < var2);
% result8 = ~var6;
% result9 = var1 + 1j*var2;
% 
% disp(var1)
% disp(class(var1))
% disp(var2)
% disp(class(var2))
% disp(var3)
% disp(class(var3))
% disp(var4)
% disp(class(var4))
% disp(var5)
% disp(class(var5))
% disp(var6)
% disp(class(var6))
% disp(var7)
% disp(class(var7))
% 
% disp('This is a string literal followed by nothing.')
% disp('')
% disp(result1)
% disp(class(result1))
% disp(result2)
% disp(class(result2))
% disp(result3)
% disp(class(result3))
% disp(result4)
% disp(class(result4))
% disp(result5)
% disp(class(result5))
% disp(result6)
% disp(class(result6))
% disp(result7)
% disp(class(result7))
% disp(result8)
% disp(class(result8))
% disp(result9)
% disp(class(result9))
% 
% disp('Let''s demonstrate escape characters and type casting.')
% disp(int32(result1))
% disp(class(int32(result1)))
% disp(logical(result1))
% disp(class(logical(result1)))
% disp(double(result7))
% disp(class(double(result7)))

% vec1 = [1, 2, 3, 4]
% disp('The length, number of elements, and size of vec1:')
% disp(length(vec1))
% disp(numel(vec1))
% disp(size(vec1))
% vec2 = [1; 2; 3; 4]
% disp('The length, number of elements, and size of vec2:')
% disp(length(vec2))
% disp(numel(vec2))
% disp(size(vec2))
% vec3 = [1; 2; 3; 4; 5; 6]
% vec4 = 25:30
% vec5 = (10:2:30).'
% vec6 = (100:-10:50).'
% vec7 = linspace(0, 2*pi, 60)
% vec8 = logspace(2, 6.8, 40)
% 
% disp('Now the Results')
% res1 = 3 * vec1
% res2 = vec6 - vec3
% res3 = vec2 + 1j*vec2
% res4 = res3.'
% res5 = res3'
% res6 = [vec1, 10, 11]
% res7 = vec4 ./ res6

% mat1 = [1, 2; 3, 4; 5, 6];
% disp('The length, number of elements, and size of mat1')
% disp(length(mat1))
% disp(numel(mat1))
% disp(size(mat1))
% mat2 = [linspace(10, 15, 3).', linspace(22, 11, 3).'];
% mat3 = 1/2 * mat1 + 1j * mat2;
% mat4 = mat3.';
% mat5 = mat3';
% mat6 = randi([0, 20], size(mat1));
% mat7 = zeros(3, 4);
% mat8 = ones(2);
% mat9 = eye(3);
% mat10 = mat6 * mat5;
% mat11 = mat3 .^ 2;
% vecx = [3, 1; -4, -2] \ [-1; 0];
% 
% disp('The mean, median, and mode of mat1 down the rows')
% disp(mean(mat1))
% disp(median(mat1))
% disp(mode(mat1))
% disp('The mean of mat1 along the columns')
% disp(mean(mat1, 2))
% disp('The median of mat1 along the columns')
% disp(median(mat1, 2))
% disp('The mode of mat9 along the columns')
% disp(mode(mat9, 2))
% disp(['The minimum, maximum, variance, and standard deviation of ' ...
% 'mat2 down the rows'])
% disp(min(mat2))
% disp(max(mat2))
% disp(var(mat2))
% disp(std(mat2))
% 
% save('workshop_data.mat', 'mat1', 'mat2', 'mat6', 'vecx')
% clear('all')

% x = linspace(0, 2, 25);
% quad_func = 2 * (x - 1) .^ 2 + 1;
% 
% fileid = fopen('workshop_quad.txt', 'w');
% fprintf(fileid, 'Quadratic Function Example\n');
% fprintf(fileid, '%1.4f %1.4f\n', [x; quad_func]);
% fclose(fileid);

% clearvars
% fileid = fopen('workshop_quad.txt', 'r');
% title = fgetl(fileid);
% data = fscanf(fileid, '%f %f\n', [2, Inf]);
% fclose(fileid);

% game_start = 1;
% game_end = 200;
% for indi = game_start:game_end
%     str_out = '';
%     if mod(indi, 3) == 0
%         str_out = [str_out, 'Fizz'];
%     end
%     if mod(indi, 5) == 0
%         str_out = [str_out, 'Buzz'];
%     end
%     if mod(indi, 7) == 0
%         str_out = [str_out, 'Bang'];
%     end
%     if mod(indi, 3) * mod(indi, 5) * mod(indi,7) ~= 0
%         str_out = num2str(indi);
%     else
%         if length(str_out) == 4
%             str_out = ['(', str_out, ')'];
%         elseif length(str_out) == 8
%             str_out = ['[', str_out, ']'];
%         else
%             str_out = ['{', str_out, '}'];
%         end
%     end
%     fprintf(1, '%s\n', str_out);
% end

% targ_err = 4.7e-7;
% indk = 0;
% pi_est = 4.0;
% rel_err = (pi_est - pi) / pi;
% while abs(rel_err) > targ_err
%     indk = indk + 1;
%     pi_est = pi_est + (-1) ^ indk * 4 / (2 * indk + 1);
%     rel_err = (pi_est - pi) / pi;
% end
% switch sign(rel_err)
%     case +1
%         word = 'greater than';
%     case -1
%         word = 'less than';
%     otherwise
%         word = '(within the precision of MATLAB) equal to';
% end
% fprintf(1, ['The estimate for pi is %1.10f, which is %s the\n' ...
%     'accepted value of pi with a relative error of %1.3g.\n'], ...
%     pi_est, word, rel_err);

clc
mat1 = [(1:6).', (7:12).', (13:18).', (19:24).', (25:30).', (31:36).'];
disp('Original matrix:')
disp(mat1)
mat1(2,1) = -7;
disp('Matrix with entry reassigned:')
disp(mat1)
mat2 = mat1(2:end,1:3);
disp('Matrix sliced in two dimensions:')
disp(mat2)
mat3 = mat1([1,3,6],:);
disp('Selected rows from matrix:')
disp(mat3)
mat4 = mat1(:,[floor(size(mat1, 2)/2) + 1:end, ...
  1:floor(size(mat1, 2)/2)]);
disp('Matrix with left and right swapped:')
disp(mat4)
mat5 = mat1(end-1:-1:1, 2:2:end);
disp('Matrix strided backwards and forwards:')
disp(mat5)

disp('Logical Indexing')
ind_div_by_5 = (mod(mat1, 5) == 0);
disp('Logical matrix of locations of multiples-of-5:')
disp(ind_div_by_5)
disp('Vector with multiples-of-5 extracted:')
disp(mat1(ind_div_by_5).')
disp('Vector of values between 5 and 31:')
disp(mat1((mat1 >= 5) & (mat1 <=31)).')
ind_near_pi_mult = find(abs(mod(mat1, pi) - pi/2) >= pi/2 - 0.5);
disp('Vector of values within one-half of pi:')
disp(mat1(ind_near_pi_mult).')
disp('Vector result using same indices on different matrix:')
disp(mat4(ind_near_pi_mult).')