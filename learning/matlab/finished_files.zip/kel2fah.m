function [temp_degF] = kel2fah(temp_K)
%KEL2FAH Converts a temperature in kelvin (K) to degrees Fahrenheit (�F)
%
% Call:
% temp_degf = kel2fah(temp_K)
%
% Inputs:
%  temp_K    = temperature in kelvin (0 K = absolute zero, standard
%              pressure freezing point of water = 273.15 K, standard
%              pressure boiling point of water = 373.15 K)
%
% Outputs:
%  temp_degF = temperature in kelvin (-459.67�F = absolute zero, standard
%              pressure freezing point of water = 32�F, standard pressure
%              boiling point of water = 212�F)
%
% Internal:
%
% Author: Michael Hayashi
% Purdue IEEE Student Branch
% Email: mhayashi@purdue.edu
% Introduction to MATLAB Workshop
% Temperature Conversion (K to �F) Function
% 16 November 2017

temp_degF = 1.8 * temp_K - 459.67;
end