%% Header
% Author: Michael Hayashi
% Purdue IEEE Student Branch
% Email: mhayashi@purdue.edu
% Introduction to MATLAB Workshop
% Analysis of Cooling Pot of Water
% 16 November 2017
% Accessible: https://purdueieee.org/learning/matlab
% Version: MATLAB(R) 2015b
% Runtime: 4.3 s
close('all')
clearvars
clc

%% Import Water Data from Excel Workbook

% Perform Import from Excel
water_data = importdata('water_cooling.xls');

% Break Structure into Strings and Arrays
data_title = water_data.textdata{1,1};
time_label = water_data.colheaders{1};
temp_label = water_data.colheaders{2};
mass_label = water_data.colheaders{3};
time = water_data.data(:,1); % Time in experiment (min)
temp = water_data.data(:,2); % Temperature of water (K)
mass = water_data.data(:,3); % Mass of water present (kg)

%% Convert Units

% Make the Data Ostentatiously Patriotic (i.e. Convert SI to Imperial)
temp_imperial = kel2fah(temp); % Temperature of water (�F)
mass_imperial = mass / 14.593903 * 32.174049; % Mass of water present (lbm)

%% Plot Data

% Figure 1: Temperature of Water During Experiment
figure(1)
plot(time, temp_imperial)
grid('on')
title('Temperature of Water after Removed from Heat')
xlabel('Time (min)')
ylabel('Temperature (�F)')
text(0.7 * time(end), 1.2 * temp_imperial(end), 0, ...
    sprintf('Final Temperature:\nT_{end} = %1.1f�F', temp_imperial(end)))

% Figure 2: Mass of Water During Experiment
figure(2)
% subplot(1, 1, 1)
plot(time, mass_imperial)
% axis([0, 120, 7.42, 7.44])
grid('on')
title('Mass of Water in Pot')
xlabel('Time (min)')
ylabel('Mass (lbm)')
text(0.5 * time(end), median(mass_imperial), 0, ...
    sprintf('Mass change: %sm = %1.3g lbm', '\Delta', ...
    mass_imperial(end) - mass_imperial(1)))
% legend('Mass', 'Location', 'Best')

%% Save Figures to File

% Create Folder for Figures if Needed
if ~exist('figures', 'dir')
    mkdir('figures');
end
cd('./figures')

% Save Figures to Dedicated Output Folder
print(1, '-dpng', sprintf('Water_Pot_Temperature_%s.jpg', date))
print(2, '-djpeg90', sprintf('Water_Pot_Mass_%s.png', date), '-r200')

% Return to Previous Folder
cd('..')